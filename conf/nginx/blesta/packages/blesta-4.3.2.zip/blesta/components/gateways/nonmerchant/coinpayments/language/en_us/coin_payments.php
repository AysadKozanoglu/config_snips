<?php
$lang['CoinPayments.name'] = 'CoinPayments.net';

$lang['CoinPayments.merchant_id'] = 'CoinPayments Merchant ID';
$lang['CoinPayments.ipn_secret'] = 'IPN Secret';
$lang['CoinPayments.buildprocess.submit'] = 'Pay with CoinPayments';
