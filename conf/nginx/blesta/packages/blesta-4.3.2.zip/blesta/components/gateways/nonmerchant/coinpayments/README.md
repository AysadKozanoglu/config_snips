# Coin Payments Gateway

A Blesta gateway that integrates with [Coin Payments](https://coinpayments.net).

Originally created by Coinpayments.net.

**To use the gateway, move it to /components/gateways/nonmerchant/ and rename it coin_payments.**