# Alipay Gateway

A Blesta gateway that integrates with [Alipay](https://global.alipay.com/).

Originally created by Phillips Data, Inc.

**To use the gateway, move it to /components/gateways/nonmerchant/ and rename it alipay.**
