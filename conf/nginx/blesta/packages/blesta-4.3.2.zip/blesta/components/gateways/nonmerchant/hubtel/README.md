# Hubtel Gateway

A Blesta gateway that integrates with [Hubtel](https://hubtel.com/).

Originally created by Phillips Data, Inc.

**To use the gateway, move it to /components/gateways/nonmerchant/ and rename it hubtel.**
