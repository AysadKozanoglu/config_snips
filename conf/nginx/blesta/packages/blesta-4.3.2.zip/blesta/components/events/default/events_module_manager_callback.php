<?php
/**
 * Handle all default ModuleManager events callbacks
 *
 * @package blesta
 * @subpackage blesta.components.events.default
 * @copyright Copyright (c) 2017, Phillips Data, Inc.
 * @license http://www.blesta.com/license/ The Blesta License Agreement
 * @link http://www.blesta.com/ Blesta
 * @deprecated since 4.3.0 - use the namespaced Events under \Blesta\Core\Util\Events\Observers\ModuleManager
 */
class EventsModuleManagerCallback extends EventCallback
{
    /**
     * Handle ModuleManager.add events
     *
     * @param EventObject $event An event object for ModuleManager.add events
     * @return EventObject The processed event object
     */
    public static function add(EventObject $event)
    {
        return parent::triggerPluginEvent($event);
    }

    /**
     * Handle ModuleManager.delete events
     *
     * @param EventObject $event An event object for ModuleManager.delete events
     * @return EventObject The processed event object
     */
    public static function delete(EventObject $event)
    {
        return parent::triggerPluginEvent($event);
    }
}
